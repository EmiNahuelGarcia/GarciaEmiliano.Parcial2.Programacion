/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Model.CSVSerializable;
import java.io.Serializable;

/**
 *
 * @author User
 */
public class Cancion implements Comparable<Cancion>, CSVSerializable, Serializable {
    private int id;
    private String titulo;
    private String artista;
    private GeneroMusical genero;

    public Cancion(int id, String titulo, String artista, GeneroMusical genero) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
    }

    
    @Override
    public int compareTo(Cancion otra) {
        return Integer.compare(otra.id, this.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + artista + "," + genero;
    }
    
    public static String toCSVHeader(){
        return "id, titulo, artista, genero";
    }

    
    public static Cancion fromCSV(String linea){
        Cancion nuevacancion = null;
        
        if(linea.endsWith("\n")){
            linea = linea.substring(0, linea.length() -1);
        }
        
        String[] values = linea.split(",");
        if(values.length == 4){
            int id = Integer.parseInt(values[0]);
            String titulo = values[1];
            String artista = values[2];
            GeneroMusical genero = GeneroMusical.valueOf(values[3]);
            nuevacancion = new Cancion(id, titulo, artista, genero);
        }
        return nuevacancion;
    }

    @Override
    public String toString() {
        return id + " / " + titulo + " / " + artista + " / " + genero;
    }

    // Getters
    public int getId() { 
        return id; 
    }
    public String getTitulo() { 
        return titulo; 
    }
    public String getArtista() { 
        return artista; 
    }
    public GeneroMusical getGenero() { 
        return genero; 
    }
}
