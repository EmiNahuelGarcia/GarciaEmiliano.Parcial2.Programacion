/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author User
 */
public class CatalogoMusical<T extends CSVSerializable & Comparable<T>> implements Serializable {

    private List<T> elementos = new ArrayList<>();

    public void agregar(T elemento) {
        if (elemento != null) {
            elementos.add(elemento);
        }
    }

    public T obtenerPorIndice(int indice) {
        if (indice >= 0 && indice < elementos.size()) {
            return elementos.get(indice);
        } else {
            throw new ArrayIndexOutOfBoundsException("Índice fuera de rango: " + indice);
        }
    }

    public List<T> getElementos() {
        return elementos;
    }

    public void eliminarPorIndice(int indice) {
        elementos.remove(indice);
    }

    public List<T> filtrar(Predicate<T> condicion) {
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (condicion.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public void ordenar() {
        Collections.sort(elementos);
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    public void paraCadaElemento(Consumer<T> accion){
        for(T elemento : elementos){
            accion.accept(elemento);
        }
    }

    public void guardarEnArchivo(List<Cancion> elementos1, String ruta) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ruta))) {
            out.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) in.readObject();
        }
    }
    

    public void guardarEnCSV(String ruta) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                writer.println(elemento.toCSV());
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        elementos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                elementos.add(fromCSV.apply(linea));
            }
        }
    }
}
