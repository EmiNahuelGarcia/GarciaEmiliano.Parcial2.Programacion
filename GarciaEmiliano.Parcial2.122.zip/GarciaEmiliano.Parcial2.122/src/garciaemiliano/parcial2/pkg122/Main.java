/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package garciaemiliano.parcial2.pkg122;

import Config.Resources;
import Model.Cancion;
import Model.CatalogoMusical;
import Model.GeneroMusical;
import java.io.IOException;

/**
 *
 * @author User
 */
public class Main {

    public static void main(String[] args) {
        try {
            CatalogoMusical<Cancion> catalogo = new CatalogoMusical<>();

            catalogo.agregar(new Cancion(1, "Bohemian Rhapsody", "Queen", GeneroMusical.ROCK));
            catalogo.agregar(new Cancion(2, "Billie Jean", "Michael Jackson",
                    GeneroMusical.POP));
            catalogo.agregar(new Cancion(3, "Shape of You", "Ed Sheeran", GeneroMusical.POP));
            catalogo.agregar(new Cancion(4, "Take Five", "Dave Brubeck", GeneroMusical.JAZZ));
            catalogo.agregar(new Cancion(5, "Canon in D", "Pachelbel", GeneroMusical.CLASICA));

            System.out.println("Catálogo de canciones:");
            catalogo.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCanciones de género POP:");
            catalogo.filtrar(c -> c.getGenero() == GeneroMusical.POP)
                    .forEach(c -> System.out.println(c));

            System.out.println("\nCanciones cuyo título contiene 'shape':");
            catalogo.filtrar(c -> c.getTitulo().toLowerCase().contains("shape"))
                    .forEach(c -> System.out.println(c));

            System.out.println("\nCanciones ordenadas por ID:");
            catalogo.ordenar();
            catalogo.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCanciones ordenadas por artista:");
            catalogo.ordenar((c1, c2) -> c1.getArtista().compareTo(c2.getArtista()));
            catalogo.paraCadaElemento(c -> System.out.println(c));

            catalogo.guardarEnArchivo(catalogo.getElementos(), Resources.getRutaBinarioString());

            CatalogoMusical<Cancion> cargado = new CatalogoMusical<>();

            cargado.cargarDesdeArchivo(Resources.getRutaBinarioString());
            System.out.println("\nCanciones cargadas desde binario:");
            cargado.paraCadaElemento(c -> System.out.println(c));

            catalogo.guardarEnCSV(Resources.getRutaCSVString());
            cargado.cargarDesdeCSV(Resources.getRutaCSVString(), linea -> Cancion.fromCSV(linea));
            System.out.println("\nCanciones cargadas desde CSV:");
            cargado.paraCadaElemento(c -> System.out.println(c));
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

}
