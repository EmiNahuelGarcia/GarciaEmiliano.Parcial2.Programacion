/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author User
 */
public interface Resources {
    
    static final String BASE = "src/Resources";
    static final String FILE_CSV = "canciones.csv";
    static final String FILE_BIN = "canciones.dat";
    
    public static Path getRutaCSV(){
        return Paths.get(BASE, FILE_CSV);
    }
    
    public static Path getRutaBinario(){
        return Paths.get(BASE, FILE_BIN);
    }
    
    public static String getRutaCSVString(){
        return getRutaCSV().toString();
    }
    
    public static String getRutaBinarioString(){
        return getRutaBinario().toString();
    }   
}
